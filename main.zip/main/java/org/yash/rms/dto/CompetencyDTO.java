package org.yash.rms.dto;

public class CompetencyDTO {
  private int id;
  private String skill;
  
  public CompetencyDTO() {}
  
  public int getId() {
    return id;
  }
  
  public void setId(int id) {
    this.id = id;
  }
  
  public String getSkill() {
    return skill;
  }
  
  public void setSkill(String skill) {
    this.skill = skill;
  }
}
