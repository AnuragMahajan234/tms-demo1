package org.yash.rms.dao;

import java.util.List;

import org.yash.rms.domain.ClientType;

public interface ClientTypeDao {
	public List<ClientType> getAllClientTypes();
}
