package org.yash.rms.dao;

import org.yash.rms.domain.RequestRequisitionResourceStatus;

public interface RequestRequisitionResourceStatusDao {
	
	public RequestRequisitionResourceStatus findById(Integer id);
}
