package org.yash.rms.dao;

import org.yash.rms.domain.SkillProfileSecondary;

public interface SkillProfileSecondaryDao extends RmsCRUDDAO<SkillProfileSecondary>{

}
