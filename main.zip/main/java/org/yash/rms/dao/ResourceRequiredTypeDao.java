package org.yash.rms.dao;

import java.util.List;

import org.yash.rms.domain.ResourceRequiredType;

public interface ResourceRequiredTypeDao {
	public List<ResourceRequiredType> getResourceRequiredTypes();
}
