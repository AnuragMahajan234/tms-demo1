package org.yash.rms.dao;

import java.util.List;

import org.yash.rms.domain.ReasonForReplacement;

public interface ReasonForReplacementDao {

	public List<ReasonForReplacement> getAllReasons();
	
}
