package org.yash.rms.dao.impl;

import org.springframework.stereotype.Repository;
import org.yash.rms.dao.UserDao;

@Repository("UserDaoImpl")
public class UserDaoImpl implements UserDao{
	
	public void save() {
	}
}
