package org.yash.rms.dao;

public interface UserDao {
	public void save();

}
