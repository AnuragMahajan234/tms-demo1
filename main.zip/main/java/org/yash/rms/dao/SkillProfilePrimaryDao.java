package org.yash.rms.dao;

import org.yash.rms.domain.SkillProfilePrimary;

public interface SkillProfilePrimaryDao extends RmsCRUDDAO<SkillProfilePrimary>{

}
