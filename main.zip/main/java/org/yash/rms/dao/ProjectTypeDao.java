package org.yash.rms.dao;

import java.util.List;

import org.yash.rms.domain.ProjectType;

public interface ProjectTypeDao {

	public List<ProjectType> getAllProjectTypes();
	
}
