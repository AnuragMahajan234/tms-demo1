package org.yash.rms.dao;

import java.util.List;

import org.yash.rms.domain.Priority;

public interface PriorityDao {

	public List<Priority> getAllPriorityTypes();
	
}
