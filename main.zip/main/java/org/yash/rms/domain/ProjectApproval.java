package org.yash.rms.domain;

import javax.persistence.Table;



@Table(name= "PROJECT_APPROVAL")
public class ProjectApproval {

	
	
	
}
