package org.yash.rms.domain;
public  class ApproveStatus {
    public final static Character NOT_APPROVED = new Character('N');
    public final static Character APPROVED = new Character('A');
    public final static Character REJECTED = new Character('R');
    public final static Character SUBMITTED = new Character('P');
}