package org.yash.rms.mapper;

public class DesignationMapper {

}
