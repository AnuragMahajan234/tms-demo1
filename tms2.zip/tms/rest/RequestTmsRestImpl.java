package org.yash.tms.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.yash.rms.dao.LocationDao;
import org.yash.rms.domain.InfogramActiveResource;
import org.yash.rms.domain.Location;
import org.yash.rms.domain.Project;
import org.yash.rms.domain.Resource;
import org.yash.rms.dto.UserContextDetails;
import org.yash.rms.exception.DaoRestException;
import org.yash.rms.exception.RestException;
import org.yash.rms.rest.utils.ExceptionUtil;
import org.yash.rms.service.ProjectService;
import org.yash.rms.service.ResourceService;
import org.yash.rms.util.GenericSearch;
import org.yash.rms.util.UserUtil;
import org.yash.tms.dao.TechnologyTMSDao;
import org.yash.tms.domain.RequestTms;
import org.yash.tms.domain.Status;
import org.yash.tms.domain.Status.Type;
import org.yash.tms.payload.RequestTmsPayload;
import org.yash.tms.domain.TechnologyTMS;
import org.yash.tms.service.RequestTmsService;
import org.yash.tms.service.StatusService;
import org.yash.tms.wrapper.RequestTmsWrapper;

@Path("/RequestTms")
@Service("RequestTmsRestImpl")
public class RequestTmsRestImpl {

	private static final Logger logger = LoggerFactory.getLogger(RequestTmsRestImpl.class);

	@Autowired
	private RequestTmsService requestTmsService;

	@Autowired
	private TechnologyTMSDao technologyTMSDao;

	@Autowired
	private LocationDao locationDao;

	@Autowired
	private ResourceService resourceService;

	@Autowired
	private UserUtil userUtil;

	@Autowired
	private ProjectService projectService;

	@Autowired
	private StatusService statusService;

	@POST
	@Path("requests")
	@Produces("application/json")
	@Consumes("application/json")
	public ResponseEntity<?> create(@Valid RequestTmsWrapper requestTmsWrapper) throws RestException {
		try {
			logger.info("--------create method for RequesttTms starts--------");
			List<RequestTmsPayload> techList = requestTmsWrapper.getTechnologyTMS();
			if (techList.size() > 1) {
				for (RequestTmsPayload requestTmsPayload : techList) {
					RequestTms req1 = getRequestObject(requestTmsWrapper);
					req1.setTechnologyTMS(technologyTMSDao.getAllTechnologyById(requestTmsPayload.getId()));
					requestTmsService.create(req1);
				}
				logger.info("--------create method for RequestTms ends--------");
				return new ResponseEntity(HttpStatus.OK);
			} else {
				RequestTms request = getRequestObject(requestTmsWrapper);
				request.setTechnologyTMS(technologyTMSDao.getAllTechnologyById(techList.get(0).getId()));
				requestTmsService.create(request);
				logger.info("--------create method for RequestTms ends--------");
				return new ResponseEntity(HttpStatus.OK);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.error("Error Inside  @class :" + this.getClass().getName() + " @Method :search" + ex.getMessage());
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest", "RequestTms", ex));
		}
	}

	private RequestTms getRequestObject(RequestTmsWrapper requestTmsWrapper) throws Exception {
		RequestTms req1 = new RequestTms();
		req1.setBatchSize(requestTmsWrapper.getBatchSize());
		Project project1 = projectService.findProject(requestTmsWrapper.getBusiness_justification());
		req1.setBusiness_justification(project1);
		req1.setCustomBusinessJustification(requestTmsWrapper.getCustomBusinessJustification());
		req1.setEmployeeId(requestTmsWrapper.getEmployeeId());
		req1.setEnd_date(requestTmsWrapper.getEnd_date());
		Location location1 = locationDao.findLocationByName(requestTmsWrapper.getLocation());
		req1.setLocation(location1);
		req1.setPriority(requestTmsWrapper.getPriority());
		req1.setRequestorBgBu(requestTmsWrapper.getRequestorBgBu());
		req1.setRequestorName(requestTmsWrapper.getRequestorName());
		req1.setStart_date(requestTmsWrapper.getStart_date());
		req1.setRequestorBgBu(requestTmsWrapper.getRequestorBgBu());
		req1.setTrainingMode(requestTmsWrapper.getTrainingMode());
		req1.setTrainingType(requestTmsWrapper.getTrainingType());
		List<Resource> resourcelist1 = new ArrayList();
		List<RequestTmsPayload> resList = requestTmsWrapper.getTrainees();
		for (RequestTmsPayload requestTmsPayload1 : resList) {
			resourcelist1.add(resourceService.findById(requestTmsPayload1.getId()));
		}
		req1.setTrainees(resourcelist1);
		Status status = new Status();
		status.setType(Type.Request);
		status.setTypeAction(requestTmsWrapper.getStatus());
		req1.setStatus(statusService.entityCreateStatus(status));
		return req1;
	}

	@Path("requests")
	@Produces("application/json")
	@GET
	public List getAllRequestTmsWithPagination(@DefaultValue("0") @QueryParam("llimit") Integer lowerLimit,
			@DefaultValue("9") @QueryParam("ulimit") Integer upperLimit) {

		logger.info("--------getAllRequestTmsWithPagination method starts--------");
		List<RequestTmsWrapper> listOfRequest = new ArrayList<RequestTmsWrapper>();
		List<RequestTms> listOfReq = requestTmsService.getAllRequestTms(lowerLimit, upperLimit);

		for (RequestTms requestTmsObject : listOfReq) {
			RequestTmsWrapper requestTmsWrapper = new RequestTmsWrapper();
			requestTmsWrapper.setRequestId(requestTmsObject.getRequestId());
			requestTmsWrapper.setRequestorName(requestTmsObject.getRequestorName());
			List<RequestTmsPayload> techlist = new ArrayList();
			TechnologyTMS technology = requestTmsObject.getTechnologyTMS();
			RequestTmsPayload tech = new RequestTmsPayload();
			tech.setId(technology.getTechnologyId());
			tech.setValue(technology.getTechName());
			techlist.add(tech);
			requestTmsWrapper.setTechnologyTMS(techlist);
			requestTmsWrapper.setPriority(requestTmsObject.getPriority());
			requestTmsWrapper.setEnd_date(requestTmsObject.getEnd_date());
			requestTmsWrapper.setLocation(requestTmsObject.getLocation().getLocation());
			requestTmsWrapper.setTrainingMode(requestTmsObject.getTrainingMode());
			requestTmsWrapper.setBatchSize(requestTmsObject.getBatchSize());
			requestTmsWrapper.setStatus(requestTmsObject.getStatus().getTypeAction());
			listOfRequest.add(requestTmsWrapper);
		}
		logger.info("--------getAllRequestTmsWithPagination method ends--------");
		return listOfRequest;
	}

	@Path("requests/{id}")
	@Produces("application/json")
	@GET
	public RequestTms getAllRequestTmsById(@PathParam("id") Integer id,@Context SearchContext context) {

		logger.info("--------getAllRequestTmsById method starts--------");

		return requestTmsService.findById(id);

	}

	@Path("requests/requestFormData")
	@Produces("application/json")
	@GET
	public Map<String, List<RequestTmsPayload>> getAllRequestFormData() {
		logger.info("--------getAllRequestFormData method starts--------");
		UserContextDetails userContextDetails = UserUtil.getCurrentResource();
		Resource resource = resourceService.getCurrentResource(userContextDetails.getUserName());
		Map<String, List<RequestTmsPayload>> fetchRequestFormData = new HashMap<String, List<RequestTmsPayload>>();

		try {
			// technologyList
			List<RequestTmsPayload> technologyList = new ArrayList();
			List<TechnologyTMS> techList = technologyTMSDao.getAllTechnology();
			for (TechnologyTMS technologyTMS : techList) {
				RequestTmsPayload technology = new RequestTmsPayload();
				technology.setId(technologyTMS.getTechnologyId());
				technology.setValue(technologyTMS.getTechName());
				technologyList.add(technology);
			}

			// locationList
			List<RequestTmsPayload> locationList = new ArrayList();
			List<Location> locList = locationDao.findAll();
			for (Location loc : locList) {
				RequestTmsPayload location = new RequestTmsPayload();
				location.setId(loc.getId());
				location.setValue(loc.getLocation());
				locationList.add(location);
			}

			// projectList
			List<RequestTmsPayload> projectList = new ArrayList();
			List<Project> proList = projectService.findAllProjectByBUid(resource.getCurrentBuId().getId());
			for (Project pro : proList) {
				RequestTmsPayload project = new RequestTmsPayload();
				project.setId(pro.getId());
				project.setValue(pro.getProjectName());
				projectList.add(project);
			}

			// resource list
			List<RequestTmsPayload> resourceList = new ArrayList();
			List<Resource> resList = resourceService.findResourceByROLE(resource.getUserRole());
			for (Resource res : resList) {
				RequestTmsPayload trainee = new RequestTmsPayload();
				trainee.setId(res.getEmployeeId());
				trainee.setValue(res.getUsername());
				resourceList.add(trainee);
			}

			// trainingMode
			List<RequestTmsPayload> trainingMode = new ArrayList();
			RequestTmsPayload mode1 = new RequestTmsPayload();
			mode1.setId(1);
			mode1.setValue("ONLINE");

			RequestTmsPayload mode2 = new RequestTmsPayload();
			mode2.setId(2);
			mode2.setValue("OFFLINE");

			trainingMode.add(mode1);
			trainingMode.add(mode2);

			// trainingType
			List<RequestTmsPayload> trainingType = new ArrayList();
			RequestTmsPayload type1 = new RequestTmsPayload();
			type1.setId(1);
			type1.setValue("OPEN");

			RequestTmsPayload type2 = new RequestTmsPayload();
			type2.setId(2);
			type2.setValue("CLOSED");

			trainingType.add(type1);
			trainingType.add(type2);

			// trainingPriority
			List<RequestTmsPayload> trainingPriority = new ArrayList();
			RequestTmsPayload p1 = new RequestTmsPayload();
			p1.setId(1);
			p1.setValue("HIGH");

			RequestTmsPayload p2 = new RequestTmsPayload();
			p2.setId(2);
			p2.setValue("MEDIUM");

			RequestTmsPayload p3 = new RequestTmsPayload();
			p3.setId(3);
			p3.setValue("LOW");

			trainingPriority.add(p1);
			trainingPriority.add(p2);
			trainingPriority.add(p3);

			fetchRequestFormData.put("technologyList", technologyList);
			fetchRequestFormData.put("locationList", locationList);
			fetchRequestFormData.put("projectList", projectList);
			fetchRequestFormData.put("trainingMode", trainingMode);
			fetchRequestFormData.put("trainingType", trainingType);
			fetchRequestFormData.put("trainingPriority", trainingPriority);
			fetchRequestFormData.put("resourceList", resourceList);

		} catch (DaoRestException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("--------getAllRequestFormData method ends--------");
		return fetchRequestFormData;
	}

	@GET
	@Path("requests/search")
	@Produces("application/json")
	public List<RequestTms> search(@DefaultValue("0") @QueryParam("llimit") Integer lowerLimit,
			@DefaultValue("9") @QueryParam("ulimit") Integer upperLimit,
			@DefaultValue("id") @QueryParam("orderBy") String orderBy,
			@DefaultValue("desc") @QueryParam("orderType") String orderType, @Context SearchContext context)
			throws RestException {
		try {
			logger.debug("Searching resources by limit from " + lowerLimit + " to " + upperLimit
					+ " order by {} and orderType {} ", orderBy, orderType);
			// return
			// infogramActiveResourceService.searchWithLimit(context,upperLimit,lowerLimit);
			return requestTmsService.searchWithLimitAndOrderBy(context, upperLimit, lowerLimit, orderBy, orderType);
		} catch (Exception ex) {
			logger.error("Error Inside  @class :" + this.getClass().getName() + " @Method :search" + ex.getMessage());
			// throw new Exception(ex.getMessage());
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest", "RequestTms", ex));
		}
	}

	@PUT
	@Path("requests")
	@Produces("application/json")
	@Consumes("application/json")
	public RequestTms update(@Valid RequestTms requestTms) throws RestException {
		try {
			logger.debug("Update RequestTms inside update methode");

			return requestTmsService.update(requestTms);
		} catch (Exception ex) {
			logger.error("Error Inside  @class :" + this.getClass().getName() + " @Method :update" + ex.getMessage());
			// throw new Exception(ex.getMessage());
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest", "InfogramActiveResource", ex));
		}
	}

	@DELETE
	@Path("requests/{id}")
	public void removeById(@PathParam("id") Integer primaryKey) throws RestException {
		try {
			logger.debug("Call for removing FileResource Object by primary key :" + primaryKey);
			requestTmsService.removeById(primaryKey);
		} catch (Exception ex) {
			logger.error("Error  occurred  @class" + this.getClass().getName(), ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest", "FileResource", ex));
		}
	}
}
