package org.yash.tms.service;

import java.util.List;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.yash.rms.domain.InfogramActiveResource;
import org.yash.rms.exception.BusinessException;
import org.yash.rms.exception.DaoRestException;
import org.yash.rms.rest.service.generic.IGenericService;
import org.yash.tms.domain.RequestTms;

public interface RequestTmsService extends IGenericService<Integer, RequestTms>{

    public List<RequestTms> getAllRequestTms(Integer lowerLimit,Integer upperLimit);
    
    public RequestTms findById(Integer id);
	
	public List<RequestTms> findAllByFields();
	
	public RequestTms create(RequestTms requestTms) throws Exception;
	
	public RequestTms update(RequestTms requestTms) throws Exception;
	
	public void removeById(Integer primaryKey) throws BusinessException;

}
