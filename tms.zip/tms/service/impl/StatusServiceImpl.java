package org.yash.tms.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.yash.rms.domain.Resource;
import org.yash.rms.dto.UserContextDetails;
import org.yash.rms.exception.DAOException;
import org.yash.rms.exception.DaoRestException;
import org.yash.rms.exception.RMSServiceException;
import org.yash.rms.exception.RestException;
import org.yash.rms.service.ResourceService;
import org.yash.rms.util.UserUtil;
import org.yash.tms.dao.StatusDao;
import org.yash.tms.domain.Status;
import org.yash.tms.exception.TMSServiceException;
import org.yash.tms.service.StatusService;

@Service
@Transactional
public class StatusServiceImpl implements StatusService {

	private static final Logger logger = LoggerFactory.getLogger(StatusServiceImpl.class); 
	
	@Autowired
	StatusDao statusDao;

	public Status entityCreateStatus(Status status) throws Exception {
		
		logger.info("--------entityCreateStatus StatusServiceImpl method starts--------");
		
		Status statusNew = null;
		UserContextDetails userContextDetails = UserUtil.getCurrentResource();
		status.setActivity(status.getType() + " is " + status.getTypeAction() + " by " + userContextDetails.getUsername());
		statusNew = statusDao.create(status);
		
		logger.info("--------entityCreateStatus StatusServiceImpl method ends--------");
		return statusNew;
	}
 
	public Status entityUpdateStatus(Status status) throws Exception {
		logger.info("--------entityUpdateStatus StatusServiceImpl method starts--------");
		Status statusNew = null;
		UserContextDetails userContextDetails = UserUtil.getCurrentResource();
		status.setActivity(status.getType() + " is " + status.getTypeAction() + " by " + userContextDetails.getUsername());
		statusNew = statusDao.update(status);
		
		logger.info("--------entityUpdateStatus StatusServiceImpl method ends--------");
		return statusNew;
	}
 
	public List<Status> getAllEntityStatusByTypeId(Integer typeId) {
		logger.info("--------getAllEntityStatusByTypeId StatusServiceImpl method starts--------");
		TMSServiceException serviceException = new TMSServiceException();
		List<Status> listStatus = new ArrayList<Status>();
		try {
			listStatus = statusDao.getStatusByTypeId(typeId);
		} catch (DAOException exception) {
			throw new TMSServiceException(exception.getErrCode(), exception.getMessage());
		}
		
		logger.info("--------getAllEntityStatusByTypeId StatusServiceImpl method ends--------");
		return listStatus;
	}
 
	public List<Status> searchWithLimit(SearchContext context, Integer maxLimit, Integer minLimit) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
 
	public List<Status> searchWithLimitAndOrderBy(SearchContext ctx, Integer maxLimit, Integer minLimit, String orderby,
			String orderType) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
 
	public void removeById(Integer primaryKey) throws RestException, DaoRestException {
		// TODO Auto-generated method stub
		
	}
	public List<Status> search(Status entity) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
 
 
	public Status create(Status entity) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
