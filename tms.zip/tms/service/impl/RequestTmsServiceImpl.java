package org.yash.tms.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.yash.rms.dto.UserContextDetails;
import org.yash.rms.exception.BusinessException;
import org.yash.rms.exception.DaoRestException;
import org.yash.rms.exception.RestException;
import org.yash.rms.rest.utils.ExceptionUtil;
import org.yash.rms.rest.utils.QueryObject.SortOrder;
import org.yash.rms.service.LocationService;
import org.yash.rms.service.ResourceService;
import org.yash.rms.util.UserUtil;
import org.yash.tms.dao.RequestTmsDao;
import org.yash.tms.domain.RequestTms;
import org.yash.tms.domain.Status;
import org.yash.tms.exception.TMSServiceException;
import org.yash.tms.service.StatusService;
import org.yash.tms.service.RequestTmsService;

@Service
@Transactional
public class RequestTmsServiceImpl implements RequestTmsService {
	
	private static final Logger logger = LoggerFactory.getLogger(RequestTmsServiceImpl.class); 
	
	@Autowired
	private RequestTmsDao requestTmsDao;
	
	@Autowired
	ResourceService resourceService;
	
	@Autowired
	LocationService locationService;
	
	@Autowired
	StatusService statusService;
	
	public List<RequestTms> getAllRequestTms(Integer lowerLimit,Integer upperLimit) {
		
		logger.info("--------getAllRequestTms RequestTmsServiceImpl method starts--------");
		
		TMSServiceException serviceException = new TMSServiceException();
		List<RequestTms> requestList = new ArrayList<RequestTms>();
		try {
			requestList = requestTmsDao.getAllRequestTmsWithPagination(lowerLimit, upperLimit,"requestId",SortOrder.DESC);
		} catch (DaoRestException exception) {
			throw new TMSServiceException(exception.getErrCode(), exception.getMessage());
		}
		logger.info("--------getAllRequestTms RequestTmsServiceImpl method ends--------");
		return requestList;
	}
	
	public List<RequestTms> getAllRequestTms() {
		
		logger.info("--------getAllRequestTms RequestTmsServiceImpl method starts--------");
		
		TMSServiceException serviceException = new TMSServiceException();
		List<RequestTms> requestList = new ArrayList<RequestTms>();
		try {
			requestList = requestTmsDao.getAllRequestTms();
		} catch (DaoRestException exception) {
			throw new TMSServiceException(exception.getErrCode(), exception.getMessage());
		}
		logger.info("--------getAllRequestTms RequestTmsServiceImpl method ends--------");
		return requestList;
	}
	

	public RequestTms findById(Integer id) {
		logger.info("--------findById RequestTmsServiceImpl method starts--------");
		RequestTms request = null;
		try {
			request =requestTmsDao.findById(id);
			return request;
		} catch (DaoRestException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("--------findById RequestTmsServiceImpl method ends--------");
		return request;
	}
	
		public List<RequestTms> findAllByFields() {
		logger.info("--------findById RequestTmsServiceImpl method starts--------");
		List<RequestTms> request = new ArrayList<RequestTms>();;
		try {
			request =requestTmsDao.findAllByFields();
			return request;
		} catch (DaoRestException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("--------findById RequestTmsServiceImpl method ends--------");
		return request;
	}

	
	public RequestTms create(RequestTms requestTms) throws Exception {
		logger.info("--------create RequestTmsServiceImpl method starts--------");
		RequestTms request = requestTmsDao.create(requestTms);
		System.out.println(request.getRequestId());
		Status status = request.getStatus();
		status.setTypeId(request.getRequestId());
		statusService.entityUpdateStatus(status);
		logger.info("--------create RequestTmsServiceImpl method ends--------");
		return request;
		
	}

	public void removeById(Integer primaryKey) {
		logger.info("--------delete RequestTmsServiceImpl method starts--------");
		try {
			requestTmsDao.deleteByPk(primaryKey);
			}catch(DaoRestException ex)
			{
				throw new BusinessException(ex);
			}
		
	}



	public RequestTms update(RequestTms requestTms) throws Exception {
		logger.info("--------create RequestTmsServiceImpl method starts--------");
		RequestTms request = requestTmsDao.update(requestTms);
		System.out.println(request.getRequestId());
		Status status = request.getStatus();
		status.setTypeId(request.getRequestId());
		statusService.entityCreateStatus(status);
		logger.info("--------create RequestTmsServiceImpl method ends--------");
		return request;
	}

	public List<RequestTms> search(RequestTms entity) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	
	public List<RequestTms> searchWithLimit(SearchContext context, Integer maxLimit, Integer minLimit)
			throws Exception {
		logger.info("requestTmsServiceImpl :: searchWithLimit - start");
		try{
			return requestTmsDao.searchWithLimit(context, maxLimit, minLimit);
		}catch(Exception ex)
		{
			logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :searchWithLimit"+ex.getMessage());
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","RequestTms",ex));
		}
	}

	public List<RequestTms> searchWithLimitAndOrderBy(SearchContext ctx, Integer maxLimit, Integer minLimit,
			String orderby, String orderType) throws Exception {
		logger.info("requestTmsServiceImpl :: searchWithLimitAndOrderBy - start");
		try{
			return requestTmsDao.searchWithLimitAndOrderBy(ctx, maxLimit, minLimit, orderby, orderType);
			}catch(Exception ex)
			{
			logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :searchWithLimitAndOrderBy()"+ex.getMessage());
				
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","RequestTms",ex));	
			}
	}



}
