package org.yash.tms.service;

import java.util.List;

import org.yash.rms.rest.service.generic.IGenericService;
import org.yash.tms.domain.Status;

public interface StatusService extends IGenericService<Integer, Status> {
	Status entityCreateStatus(Status status) throws Exception;

	Status entityUpdateStatus(Status status) throws Exception;
	
	List<Status> getAllEntityStatusByTypeId(Integer typeId);
	
}
