package org.yash.tms.payload;
import java.util.List;
import java.util.Map;

public class RequestFormPayload {

	private Map<String, List<RequestTmsPayload>> listRequestPayload;
	private Map<String, List<String>> enumsRequestPayload;

	public Map<String, List<RequestTmsPayload>> getListRequestPayload() {
		return listRequestPayload;
	}

	public void setListRequestPayload(Map<String, List<RequestTmsPayload>> listRequestPayload) {
		this.listRequestPayload = listRequestPayload;
	}

	public Map<String, List<String>> getEnumsRequestPayload() {
		return enumsRequestPayload;
	}

	public void setEnumsRequestPayload(Map<String, List<String>> enumsRequestPayload) {
		this.enumsRequestPayload = enumsRequestPayload;
	}

}