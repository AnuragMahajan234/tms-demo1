package org.yash.tms.dao;

import java.util.List;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.yash.rms.exception.DaoRestException;
import org.yash.rms.rest.utils.QueryObject.SortOrder;
import org.yash.tms.domain.RequestTms;

public interface RequestTmsDao {

	public List<RequestTms> getAllRequestTms(int lowerLimit,int upperLimit,String orderby, SortOrder sort) throws DaoRestException;
	
	public RequestTms findById(Integer id) throws DaoRestException;
	
	public RequestTms findAllByFields() throws DaoRestException;
	
	public RequestTms create(RequestTms requestTms) throws DaoRestException;
	
	public RequestTms update(RequestTms requestTms) throws DaoRestException;
	
	public void deleteByPk(Integer entityPk) throws DaoRestException;
	
    public List<RequestTms> searchWithLimitAndOrderBy(SearchContext ctx,Integer maxLimit, Integer minLimit, String orderby, String orderType)throws DaoRestException;
	
	public List<RequestTms> searchWithLimit(SearchContext context, Integer maxLimit, Integer minLimit) throws DaoRestException;

	
}
