package org.yash.tms.dao;

import java.util.List;

import org.yash.rms.domain.InfogramActiveResource;
import org.yash.rms.exception.DAOException;
import org.yash.rms.exception.DaoRestException;
import org.yash.tms.domain.Status;


public interface StatusDao {

	Status create(Status status) throws DaoRestException;

	Status update(Status status) throws DaoRestException;
	
	List<Status> getStatusByTypeId(Integer typeId) throws DAOException;
}
