package org.yash.tms.dao;

import java.util.List;

import org.yash.rms.exception.DaoRestException;
import org.yash.tms.domain.TechnologyTMS;

public interface TechnologyTMSDao {

	public List<TechnologyTMS> getAllTechnology() throws DaoRestException;
	public TechnologyTMS getAllTechnologyById(Integer technologyId) throws DaoRestException;
}
