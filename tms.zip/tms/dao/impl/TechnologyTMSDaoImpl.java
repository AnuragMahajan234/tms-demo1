package org.yash.tms.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.yash.rms.exception.DaoRestException;
import org.yash.rms.rest.dao.generic.impl.HibernateGenericDao;
import org.yash.tms.dao.RequestTmsDao;
import org.yash.tms.dao.TechnologyTMSDao;
import org.yash.tms.domain.RequestTms;
import org.yash.tms.domain.TechnologyTMS;

@Repository
public class TechnologyTMSDaoImpl extends HibernateGenericDao<Integer, TechnologyTMS> implements TechnologyTMSDao {

	public TechnologyTMSDaoImpl() {
		super(TechnologyTMS.class);
		// TODO Auto-generated constructor stub
	}

	public List<TechnologyTMS> getAllTechnology() throws DaoRestException {
		// TODO Auto-generated method stub
		return super.findAll();
	}

	public TechnologyTMS getAllTechnologyById(Integer technologyId) throws DaoRestException {
		// TODO Auto-generated method stub
		return super.findByPk(technologyId);
	}
	

}
