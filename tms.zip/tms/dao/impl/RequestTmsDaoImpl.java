package org.yash.tms.dao.impl;

import java.util.List;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.yash.rms.dao.impl.InfogramActiveResourceDaoImpl;
import org.yash.rms.exception.DaoRestException;
import org.yash.rms.rest.dao.generic.impl.HibernateGenericDao;
import org.yash.rms.rest.utils.ExceptionUtil;
import org.yash.rms.rest.utils.QueryObject.SortOrder;
import org.yash.tms.dao.RequestTmsDao;
import org.yash.tms.domain.RequestTms;

@Repository
public class RequestTmsDaoImpl extends HibernateGenericDao<Integer, RequestTms> implements RequestTmsDao {

	private static final Logger logger = LoggerFactory.getLogger(RequestTmsDaoImpl.class);
	
	public RequestTmsDaoImpl() {
		super(RequestTms.class);
	}

	public List<RequestTms> getAllRequestTmsWithPagination(int lowerLimit,int upperLimit,String orderby, SortOrder sort) throws DaoRestException {
		logger.info("-----------getAllRequestTms of RequestTmsDaoImpl Start-----------------------");
		logger.info("-----------getAllRequestTms of RequestTmsDaoImpl ends-----------------------");
		return super.findAllWithPagination(lowerLimit, upperLimit, orderby, sort);
	}
	
	public List<RequestTms> getAllRequestTms() throws DaoRestException {
		logger.info("-----------getAllRequestTms of RequestTmsDaoImpl Start-----------------------");
		logger.info("-----------getAllRequestTms of RequestTmsDaoImpl ends-----------------------");
		return super.findAll();
	}

	public RequestTms findById(Integer id) throws DaoRestException {
		logger.info("-----------findById of RequestTmsDaoImpl Start-----------------------");
		
		Session session = (Session) getEntityManager().getDelegate();
		RequestTms request = new RequestTms();
		try {
			request = session.createNamedQuery(RequestTms.GET_REQUEST_BY_ID, RequestTms.class)
					.setParameter("id", id).uniqueResult();
		} catch (Exception e) {
			throw new DaoRestException("503");
		}
		logger.info("-----------findById of RequestTmsDaoImpl ends-----------------------");
		return request;
	}
		public List<RequestTms> findAllByFields() throws DaoRestException {
		logger.info("-----------findById of RequestTmsDaoImpl Start-----------------------");
		
		Session session = (Session) getEntityManager().getDelegate();
		List<RequestTms> request = new ArrayList<RequestTms>();
		try {
			request = session.createNamedQuery(RequestTms.GET_CERTAIN_REQUEST_FIELDS, RequestTms.class);
		} catch (Exception e) {
			throw new DaoRestException("503");
		}
		logger.info("-----------findById of RequestTmsDaoImpl ends-----------------------");
		return request;
	}

	public RequestTms create(RequestTms requestTms) throws DaoRestException {
		logger.info("-----------create of RequestTmsDaoImpl Start-----------------------");
		logger.info("-----------create of RequestTmsDaoImpl ends-----------------------");
		return super.create(requestTms);
	}
	
	public RequestTms update(RequestTms requestTms) throws DaoRestException {
		logger.info("-----------update of RequestTmsDaoImpl Start-----------------------");
		logger.info("-----------update of RequestTmsDaoImpl ends-----------------------");
		return super.update(requestTms);
	}
	
	public void deleteByPk(Integer entityPk) throws DaoRestException{
		logger.info("-----------deleteByPk of RequestTmsDaoImpl Start-----------------------");
		try {
		logger.info("-----------deleteByPk of RequestTmsDaoImpl ends-----------------------");
			super.deleteByPk(entityPk);
		} catch (DaoRestException e) {
			throw new DaoRestException(e);
		}
	}

	public List<RequestTms> searchWithLimitAndOrderBy(SearchContext ctx, Integer maxLimit, Integer minLimit,
			String orderby, String orderType) throws DaoRestException {
		try {
			return super.search(ctx, maxLimit, minLimit, orderby, orderType);
		}catch(Exception e) {
			logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :searchWithLimitAndOrderBy "+e.getMessage());
			throw new DaoRestException(ExceptionUtil.generateExceptionCode("Dao","RequestTms",e));
		}
	}

	public List<RequestTms> searchWithLimit(SearchContext context, Integer maxLimit, Integer minLimit) throws DaoRestException {try {
				return super.search(context, maxLimit, minLimit);
			}catch(Exception e) {
				logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :searchWithLimit"+e.getMessage());
				throw new DaoRestException(ExceptionUtil.generateExceptionCode("Dao","RequestTms",e));
			}
	}


}
