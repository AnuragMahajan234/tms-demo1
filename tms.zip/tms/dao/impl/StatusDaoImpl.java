package org.yash.tms.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.yash.rms.exception.DAOException;
import org.yash.rms.exception.DaoRestException;
import org.yash.rms.rest.dao.generic.impl.HibernateGenericDao;
import org.yash.tms.dao.StatusDao;
import org.yash.tms.domain.Status;

@Repository
public class StatusDaoImpl extends HibernateGenericDao<Integer, Status> implements StatusDao {
	
	private static final Logger logger = LoggerFactory.getLogger(StatusDaoImpl.class);
	
	public StatusDaoImpl() {
		super(Status.class);
	}
 
	public Status create(Status status) throws DaoRestException {
		logger.info("-----------save of StatusDaoImpl Start-----------------------");
		logger.info("-----------save of StatusDaoImpl ends-----------------------");
		return super.create(status);
	}
 
	public Status update(Status status) throws DaoRestException {	
		logger.info("-----------update of StatusDaoImpl start-----------------------");
		logger.info("-----------update of StatusDaoImpl ends-----------------------");
		return super.update(status);
	}
 
	public List<Status> getStatusByTypeId(Integer typeId) throws DAOException {
		logger.info("-----------getStatusByTypeId of StatusDaoImpl start-----------------------");
		List<Status> listStatus = new ArrayList<Status>();
		Session session = (Session) getEntityManager().getDelegate();
		try {
			listStatus = session.createNamedQuery(Status.GET_ALL_STATUS_OF_TYPE_BY_TYPEID, Status.class)
					.setParameter("typeId", typeId).getResultList();
		} catch (Exception e) {
			throw new DAOException("503", e.getMessage());
		}
		
		logger.info("-----------getStatusByTypeId of StatusDaoImpl start-----------------------");
		return listStatus;
	}
}
