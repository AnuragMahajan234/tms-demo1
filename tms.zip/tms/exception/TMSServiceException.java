package org.yash.tms.exception;

import org.springframework.stereotype.Component;

import flexjson.JSONSerializer;

@Component
public class TMSServiceException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	 
    private String errCode;
    private String message;
    
    public TMSServiceException() {}
    
    public TMSServiceException(String errCode, String message) {
    	super();
        this.errCode = errCode;
        this.setMessage(message);
    }
    public String getErrCode() {
        return errCode;
    }
 
    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }
 
    
    public static String toJsonArray(
			org.yash.tms.exception.TMSServiceException tmsException) {
		return new JSONSerializer()
				.include("errCode", "message")
				.exclude("*").serialize(tmsException);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
