package org.yash.tms.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.yash.rms.domain.BaseEntity;

@Entity
@Table(name = "request_training_status")
@NamedQueries({
	   @NamedQuery(name=Status.GET_ALL_STATUS_OF_TYPE_BY_TYPEID, query="FROM Status WHERE typeId=:typeId")
	})
public class Status extends BaseEntity {

	public final static String GET_ALL_STATUS_OF_TYPE_BY_TYPEID = "GET_ALL_STATUS_OF_TYPE_BY_TYPEID";
	
	public static enum Type {
		Request, Training
	}

	public static enum TypeAction {
		INITIATED,APPROVED, DECLINED, HOLD, PENDING
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "request_training_status_id")
	private Integer id;

	@Enumerated(EnumType.STRING)
	private Type type;

	@Column(name = "type_fk_id")
	private Integer typeId;

	@Enumerated(EnumType.STRING)
	private TypeAction typeAction;

	@Column(name = "activity")
	private String activity;
	
	@Column(name = "comment")
	private String comment;

/*	@OneToMany(mappedBy = "id")
	private Comment_tms comment;*/

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public TypeAction getTypeAction() {
		return typeAction;
	}

	public void setTypeAction(TypeAction typeAction) {
		this.typeAction = typeAction;
	}

/*	public Comment_tms getComment() {
		return comment;
	}

	public void setComment(Comment_tms comment) {
		this.comment = comment;
	}*/

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public Status(Integer id, Type type, Integer typeId, TypeAction typeAction, String activity) {
		super();
		this.id = id;
		this.type = type;
		this.typeId = typeId;
		this.typeAction = typeAction;
		this.activity = activity;

	}

	public Status() {
		super();
	}

}
