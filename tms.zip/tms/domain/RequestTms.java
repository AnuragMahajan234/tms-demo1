package org.yash.tms.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.yash.rms.domain.Location;
import org.yash.rms.domain.Project;
import org.yash.rms.domain.Resource;
import org.yash.tms.domain.Status;

@Entity
@Table(name = "request_tms")
@NamedQueries({
	   @NamedQuery(name=RequestTms.GET_REQUEST_BY_ID, query="FROM Status WHERE id=:id"),
	   	   @NamedQuery(name=Status.GET_CERTAIN_REQUEST_FIELDS, query="select request.requestId, request.requestorName, request.priority ,request.trainingMode,request.batchSize,request.end_date,request.technologyTMS,request.location,request.status from RequestTms request")

	})
public class RequestTms {
	
	public final static String GET_REQUEST_BY_ID = "GET_REQUEST_BY_ID";
    public final static String GET_CERTAIN_REQUEST_FIELDS = "GET_CERTAIN_REQUEST_FIELDS";
	
	public static enum TrainingType {
		OPEN, CLOSED
	}

	public static enum Priority {
		LOW, MEDIUM, HIGH
	}

	public static enum TrainingMode {
		OFFLINE, ONLINE
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "request_Id")
	private int requestId;

	@Column(name = "requestor_Name")
	private String requestorName;

	@Column(name = "emp_id")
	private int employeeId;

	@Column(name = "bg_bu")
	private String requestorBgBu;
	
	@Column(name = "custom_businessJustification")
	private String customBusinessJustification;

	@Column(name = "priority")
	@Enumerated(EnumType.STRING)
	private Priority priority;

	@Column(name = "trainingType")
	@Enumerated(EnumType.STRING)
	private TrainingType trainingType;

	@Column(name = "trainingMode")
	@Enumerated(EnumType.STRING)
	private TrainingMode trainingMode;

	@Column(name = "batch_size")
	private int batchSize;

	@Column(name = "start_date")
	private Date start_date;

	@Column(name = "end_date")
	private Date end_date;

	@OneToOne(fetch = FetchType.EAGER,cascade=CascadeType.ALL)					
	@JoinColumn(name = "tech_id", referencedColumnName = "technology_id")
	private TechnologyTMS technologyTMS;

	@OneToOne
	@JoinColumn(name = "business_justification", referencedColumnName = "project_name", updatable = false)
	private Project business_justification;

	@OneToOne
	@JoinColumn(name = "location_id", referencedColumnName = "id", updatable = false)
	private Location location;

	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name = "REQUEST_TMS_RESOURCE", joinColumns = {
			@JoinColumn(name = "REQUEST_TMS_ID", referencedColumnName = "request_Id") }, inverseJoinColumns = {
					@JoinColumn(name = "RESOURCE_ID", referencedColumnName = "employee_id") })
	private List<Resource> trainees = new ArrayList<Resource>();

	@OneToOne
	@JoinColumn(name = "request_status_id", referencedColumnName = "request_training_status_id", updatable = false)
	private Status status;

	// @OneToMany(fetch = FetchType.LAZY)
	// @JoinColumn(name="comment_id" , referencedColumnName ="id" , updatable =
	// false)
	// private CommentTms comment;

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getRequestorName() {
		return requestorName;
	}

	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public TechnologyTMS getTechnologyTMS() {
		return technologyTMS;
	}

	public void setTechnologyTMS(TechnologyTMS technologyTMS) {
		this.technologyTMS = technologyTMS;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getRequestorBgBu() {
		return requestorBgBu;
	}

	public void setRequestorBgBu(String requestorBgBu) {
		this.requestorBgBu = requestorBgBu;
	}

	public String getCustomBusinessJustification() {
		return customBusinessJustification;
	}

	public void setCustomBusinessJustification(String customBusinessJustification) {
		this.customBusinessJustification = customBusinessJustification;
	}

	public Priority getPriority() {
		return priority;
	}

	public void setPriority(Priority priority) {
		this.priority = priority;
	}

	public TrainingType getTrainingType() {
		return trainingType;
	}

	public void setTrainingType(TrainingType trainingType) {
		this.trainingType = trainingType;
	}

	public TrainingMode getTrainingMode() {
		return trainingMode;
	}

	public void setTrainingMode(TrainingMode trainingMode) {
		this.trainingMode = trainingMode;
	}

	public int getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocationId(Location location) {
		this.location = location;
	}

	public List<Resource> getTrainees() {
		return trainees;
	}

	public void setTrainees(List<Resource> trainees) {
		this.trainees = trainees;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	

	public Project getBusiness_justification() {
		return business_justification;
	}

	public void setBusiness_justification(Project business_justification) {
		this.business_justification = business_justification;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public RequestTms(int requestId, String requestorName, int employeeId, String requestorBgBu,
			String customBusinessJustification, Priority priority, TrainingType trainingType, TrainingMode trainingMode,
			int batchSize, Date start_date, Date end_date, TechnologyTMS technologyTMS, Project business_justification,
			Location location, List<Resource> trainees, Status status) {
		super();
		this.requestId = requestId;
		this.requestorName = requestorName;
		this.employeeId = employeeId;
		this.requestorBgBu = requestorBgBu;
		this.customBusinessJustification = customBusinessJustification;
		this.priority = priority;
		this.trainingType = trainingType;
		this.trainingMode = trainingMode;
		this.batchSize = batchSize;
		this.start_date = start_date;
		this.end_date = end_date;
		this.technologyTMS = technologyTMS;
		this.business_justification = business_justification;
		this.location = location;
		this.trainees = trainees;
		this.status = status;
	}
	
	public RequestTms() {
		super();
		
	}

}
