package org.yash.tms.wrapper;

import java.util.Date;
import java.util.List;
import org.yash.tms.domain.RequestTms.Priority;
import org.yash.tms.domain.RequestTms.TrainingType;
import org.yash.tms.domain.Status.TypeAction;
import org.yash.tms.payload.RequestTmsPayload;
import org.yash.tms.domain.RequestTms.TrainingMode;

public class RequestTmsWrapper {

	private int requestId;
	private String requestorName;
	private int employeeId;
	private String requestorBgBu;
	private List<RequestTmsPayload> technologyTMS;
	private Priority priority;
	private TrainingType trainingType;
	private TrainingMode trainingMode;
	private int batchSize;
	private Date start_date;
	private Date end_date;
	private String location;
	private TypeAction status;
	private String comment;
	private int business_justification;
	private String customBusinessJustification;
	private List<RequestTmsPayload> trainees;

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getRequestorName() {
		return requestorName;
	}

	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getRequestorBgBu() {
		return requestorBgBu;
	}

	public void setRequestorBgBu(String requestorBgBu) {
		this.requestorBgBu = requestorBgBu;
	}

	public List<RequestTmsPayload> getTechnologyTMS() {
		return technologyTMS;
	}

	public void setTechnologyTMS(List<RequestTmsPayload> technologyTMS) {
		this.technologyTMS = technologyTMS;
	}

	public int getBusiness_justification() {
		return business_justification;
	}

	public void setBusiness_justification(int business_justification) {
		this.business_justification = business_justification;
	}

	public List<RequestTmsPayload> getTrainees() {
		return trainees;
	}

	public void setTrainees(List<RequestTmsPayload> trainees) {
		this.trainees = trainees;
	}

	public String getCustomBusinessJustification() {
		return customBusinessJustification;
	}

	public void setCustomBusinessJustification(String customBusinessJustification) {
		this.customBusinessJustification = customBusinessJustification;
	}

	public Priority getPriority() {
		return priority;
	}

	public void setPriority(Priority priority) {
		this.priority = priority;
	}

	public TrainingType getTrainingType() {
		return trainingType;
	}

	public void setTrainingType(TrainingType trainingType) {
		this.trainingType = trainingType;
	}

	public TrainingMode getTrainingMode() {
		return trainingMode;
	}

	public void setTrainingMode(TrainingMode trainingMode) {
		this.trainingMode = trainingMode;
	}

	public int getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}


	public TypeAction getStatus() {
		return status;
	}

	public void setStatus(TypeAction status) {
		this.status = status;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

}
